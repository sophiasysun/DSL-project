"song" by me
treble', c major -> d major, 3 4

verse 1 {
e M, 2, 1
c dim, 2
}
verse 1