java -jar LilyPondGenerator.jar $1 > o.txt 
lilypond --pdf -o $2 o.txt 
rm o.txt 
open $2.pdf
