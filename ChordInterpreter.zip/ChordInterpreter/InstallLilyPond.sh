#!/bin/bash
mkdir -p ~/bin
touch ~/bin/lilypond
echo "#!/bin/bash" > ~/bin/lilypond
echo "exec /Applications/LilyPond.app/Contents/Resources/bin/lilypond \"\$@\"" >> ~/bin/lilypond
chmod u+x ~/bin/lilypond
source .pathfile
