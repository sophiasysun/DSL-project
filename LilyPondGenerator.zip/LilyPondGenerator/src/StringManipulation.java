
/**
 * Represents # with is and b with es (is and es are in LilyPond syntax).
 * StringManipulation contains a method that is used in multiple classes and doesn't conceptually 
 * belong the most in any one class, so I just created a separate class with the convertSharpFlat 
 * method.
 * @author sophiasysun
 */
public class StringManipulation {

	/**
	 * @param note
	 * @return
	 */
	String convertSharpFlat(String note){
		// if only one character, definitely not a # or b
		if (note.length()==1) {
			return note;
		}
		if (note.equals("bb")) {
			note = "bes";
		}
		else if (note.contains("#")) {
			int sharp = note.indexOf("#");
			note = note.substring(0, sharp);
			note+="is";
		}
		
		// want to prevent "b flat" becoming "eses"
		else if (note.contains("b")) {
			int flat = note.indexOf("b");
			if (flat>0){
			note = note.substring(0, flat);
			note+="es";
			}
		}
		return note;
	}
}
