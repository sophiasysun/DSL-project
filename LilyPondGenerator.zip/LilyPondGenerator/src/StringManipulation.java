
public class StringManipulation {


	/**
	 * WHY DOES THIS NOT WORK
	 * @param note
	 * @return
	 */
	String convertSharpFlat(String note){
		if (note.length()==1) {
			return note;
		}
		if (note.equals("bb")) {
			note = "bes";
		}
		else if (note.contains("#")) {
			int sharp = note.indexOf("#");
			note = note.substring(0, sharp);
			note+="is";
		}
		else if (note.contains("b")) {
			int flat = note.indexOf("b");
			if (flat>0){
			note = note.substring(0, flat);
			note+="es";
			}
		}


		// in case there is double flat or sharp ????? tried replacing all # with is 
		return note;
	}
}
