import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class creates o.txt, which is written in LilyPond syntax and serves as the
 * intermediary between the user's input and the input LilyPond needs to generate
 * sheet music accordingly.
 * @author sophiasysun
 *
 */
public class NoteProducer {
	
	// keeps track of the values of various objects that will eventually be printed in the output 
	private static String clef;
	private static String octave;
	private static String songKey;
	private static String songQuality;
	private static String optionalNewKey; // if inversion 
	private static int tS_top; // time signature 
	private static int tS_bot;
	private static final int STEPS=12; // total number of notes in each of sharps, flats, sharps_eb, flats_cf 
	private int offset;
	private String title;
	private String composer; 
	
	// sharpsTranspose when original key root has sharp
	// or, if in upwards transposition, the original key either has sharps or no accidentals  
	boolean sharpsTranspose = false;
	
	// flatsTranspose when original key root has flat
	// or, if in downwards transposition, the original key either has flats or no accidentals  
	boolean flatsTranspose = false;

	public StringManipulation str = new StringManipulation();
	public QualityIntervals intervals  = new QualityIntervals ();
	
	// which interval array to use (will assign to majorTriadIntervals, 
	// minorTriadIntervals, dom7Intervals, maj7Intervals, min7Intervals, or dim7Intervals
	// depending on the quality of the chord 
	public ArrayList<Integer> intervalArray = new ArrayList<Integer> ();
	
	// the notes, in the correct order, that are generated
	public ArrayList<String> outputArray= new ArrayList<String> ();

	// from Notes class
	public Notes n = new Notes();
	public ArrayList<String> sharps = n.getSharps();
	public ArrayList<String> flats = n.getFlats();
	public ArrayList<String> sharps_eb = n.getSharps_eb();
	public ArrayList<String> flats_cf = n.getFlats_cf();
	public HashMap<String, ArrayList<String>> enharmonicChords = n.getEnharmonicChords();
	public HashMap<String, String[]> dimMap = n.getDimChords();
	public ArrayList<String> sharpExceptions = n.getSharpExceptions();
	public ArrayList<String> flatExceptions = n.getFlatExceptions();

	// Arrays of notes, in increasing half steps
	public ArrayList<Integer> majorTriadIntervals = intervals.getMaj();
	public ArrayList<Integer> minorTriadIntervals = intervals.getMin();
	public ArrayList<Integer> dom7Intervals = intervals.getDom7();
	public ArrayList<Integer> maj7Intervals = intervals.getMaj7();
	public ArrayList<Integer> min7Intervals = intervals.getMin7();
	public ArrayList<Integer> dim7Intervals = intervals.getDim7();

	public char [] adjNotes = new char [7];

	ArrayList<String> qualityArrayUsed= new ArrayList<String> ();
	int chordRootIndex = 0;
	int invIndex = 0;

	String updatedChordRoot;
	String updatedChordInv;

	public NoteProducer(String clef, String octave, String songKey, String songQuality, String optionalNewKey, int tS_top, int tS_bot, int offset, String title, String composer) {
		this.clef = clef;
		this.octave = octave;
		this.songKey = songKey;
		this.songQuality = songQuality;
		this.optionalNewKey = optionalNewKey;
		this.tS_top = tS_top;
		this.tS_bot = tS_bot;
		this.offset = offset;
		this.title = title;
		this.composer = composer;

		// in transpose this would be the old key 
		if (this.songKey.contains("is")) {
			sharpsTranspose = true;
			flatsTranspose = false;
		}
		else if (this.songKey.contains("es")) {
			flatsTranspose = true;
			sharpsTranspose = false;
		}

		else {
			// if transposing using new key signature 
			// if transpose and no accidental in original root, decide based on new key 
			if (optionalNewKey!=null) {
				if (optionalNewKey.contains("is")){
					sharpsTranspose = true;
					flatsTranspose = false;
				}
				else if (optionalNewKey.contains("es")){
					flatsTranspose = true;
					sharpsTranspose = false;
				} 
				else {
					sharpsTranspose = true;
					flatsTranspose = false;
				}
			}

			// if not transposing using new key signature 
			// if using up down optionalNewKey is null 
			else if (offset>=0){
				sharpsTranspose = true;
				flatsTranspose = false;
			}
			// transpose down = flats
			else {
				flatsTranspose = true;
				sharpsTranspose = false;
			}
		}

		// need to assign new key if using numerical transpose
		if (optionalNewKey==null) {
			int indexOfSongKey;
			if (sharpsTranspose) {
				indexOfSongKey = sharps.indexOf(songKey);
				songKey = sharps.get((indexOfSongKey+ offset + STEPS)%STEPS);
				songKey = songKey.replace("is", "#");

			}
			else if (flatsTranspose) {
				indexOfSongKey =  flats.indexOf(songKey);
				songKey = flats.get((indexOfSongKey+ offset + STEPS)%STEPS);
				songKey = songKey.replace("es", "b");
			}
		}
		if (optionalNewKey==null) {
			this.songKey = songKey;
		}
		else {
			this.songKey = optionalNewKey;
		}
	}

	/**
	 * If array contains String, return the index of that the String's appearance
	 * @param array
	 * @param s
	 * @return
	 */
	public int returnIndex(ArrayList<String> array, String s) {
		if (array == null) {
			return -1;
		}
		for (int i=0;i<array.size(); i++) {
			if(array.get(i).equals(s))  {
				return i;
			}
		}
		return -1;
	}

	/**
	 * If array contains char, return the index of that the char's appearance
	 * @param array
	 * @param s
	 * @return
	 */
	public int c_index(char [] array, char c) {
		if (array == null) {
			return -1;
		}
		for (int i=0;i<array.length; i++) {
			if(array[i]==c)  {
				return i;
			}
		}
		return -1;
	}


	/**
	 * Translate letter inversion into integer inversion
	 * by finding the inversion relationship between the 
	 * original chordRoot and original inversionNote
	 * @param root
	 * @param inv
	 */
	public void translateToNumericalInversion (String root, String inv) {

		ArrayList<String> tempArray = new ArrayList<String>();
		int oldRootIndex = qualityArrayUsed.indexOf(root);
		for (int i=0;i<intervalArray.size();i++) {
			tempArray.add(qualityArrayUsed.get((oldRootIndex+ intervalArray.get(i) + STEPS) % STEPS));
		}

		for (int i = 0;i<tempArray.size(); i++) {
			if (inv.equals(tempArray.get(i))){
				updatedChordInv = String.valueOf(i);
			}
		}
	}

	/**
	 * Shuffles the notes in an array to the right for inversion 
	 * @param array
	 * @param noteNumber
	 * @return
	 */
	public String [] shuffleArrayIndex(ArrayList<String> array, int noteNumber) {
		String[] shuffled = new String[array.size()];
		for (int i = 0; i <array.size(); i++) {
			shuffled[i] = array.get((i+noteNumber) % array.size());
		}
		String [] result = shuffled;
		return result;
	}

	public void setAdjNotes () {
		adjNotes[0]='a';
		adjNotes[1]='b';
		adjNotes[2]='c';
		adjNotes[3]='d';
		adjNotes[4]='e';
		adjNotes[5]='f';
		adjNotes[6]='g';
	}

	/** 
	 * Checks if adjacent notes in a chord have adjacent note names 
	 * @param array
	 * @param noteNumber
	 * @return
	 */
	public boolean adjacentNoteNames() {
		setAdjNotes();
		char note1=outputArray.get(0).charAt(0);
		char note2=outputArray.get(1).charAt(0);
		char note3=outputArray.get(2).charAt(0);

		// check if the first two and the second two are adjacent
		if ((Math.abs(c_index(adjNotes, note2) - c_index(adjNotes, note1)) == 1) ||
				(Math.abs(c_index(adjNotes, note2) - c_index(adjNotes, note1)) == 6) ||
				(Math.abs(c_index(adjNotes, note3) - c_index(adjNotes, note2)) == 1) ||
				(Math.abs(c_index(adjNotes, note3) - c_index(adjNotes, note2)) == 6)) {
			return true;
		}
		return false;
	}

	/**
	 * Assign intervalArray based on specified chord quality
	 * @param quality
	 */
	public void intArray(String quality) {

		if (quality.equals("major")){
			intervalArray = majorTriadIntervals;
		}
		else if (quality.equals("minor")){
			intervalArray = minorTriadIntervals;
		}
		else if (quality.equals("dom7")){
			intervalArray = dom7Intervals;
		}
		else if (quality.equals("maj7")){
			intervalArray = maj7Intervals;
		}
		else if (quality.equals("min7")){
			intervalArray = min7Intervals;
		}
		else if (quality.equals("dim7")){
			intervalArray = dim7Intervals;
		}
	}

	/**
	 * Creates header with title and composer, if specified by user
	 * @param title
	 * @param composer
	 * @return
	 */
	public String createHeader (String title, String composer) {

		if (title==null && composer==null) {
			return "";
		}
		else {
			return "\\header { " + "\n " + 
					"title = " + title + "\n " + "composer = " + "\"" + composer + "\"" + "\n" + "}" + "\n";
		}
	}

	/**
	 * Given the root and inversion of a chord, decide which qualityArrayUsed (sharps, sharps_eb,
	 * flats, flats_cf) to use
	 * @param root
	 * @param inv
	 */
	public void convertRootAndInversionOfChord (String root, String inv) {

		// if inversion is specified using a letter, make sure both chordRoot and invNote
		// can be found in the qualityArray
		// then find the new root given the offset
		// and use "translateToNumericalInversion" to find the numerical inversion 
		if (inv.matches("[A-Za-z]+")) {

			if (sharpsTranspose) {
				if (sharps.contains(root) && sharps.contains(inv)) {
					qualityArrayUsed = sharps;
				}

				else if (sharps_eb.contains(root) && sharps_eb.contains(inv) ) {
					qualityArrayUsed = sharps_eb;
				}

				else if (flats.contains(root) && flats.contains(inv)) {
					qualityArrayUsed = flats;
				}

				else if (flats_cf.contains(root) && flats_cf.contains(inv)) { 
					qualityArrayUsed = flats_cf;
				}
				else {
					System.out.println("The bottom note you specified is not in this chord!");
				}
			}

			else if (flatsTranspose) {
				if (flats.contains(root) && flats.contains(inv)) {
					qualityArrayUsed = flats; 
				}
				else if (flats_cf.contains(root) && flats_cf.contains(inv)) { 
					qualityArrayUsed = flats_cf; 
				}
				else if (sharps.contains(root) && sharps.contains(inv)) {
					qualityArrayUsed = sharps;
				}
				else if (sharps_eb.contains(root) && sharps_eb.contains(inv)) {
					qualityArrayUsed = sharps_eb;
				}
				else {
					System.out.println("The bottom note you specified is not in this chord!");
				}
			}

			// no transposition and original key has no accidentals 
			else {
				if (sharps.contains(root) && sharps.contains(inv)) {
					qualityArrayUsed = sharps;
				}

				else if (sharps_eb.contains(root) && sharps_eb.contains(inv) ) {
					qualityArrayUsed = sharps_eb;
				}

				else if (flats.contains(root) && flats.contains(inv)) {
					qualityArrayUsed = flats;
				}

				else if (flats_cf.contains(root) && flats_cf.contains(inv)) { 
					qualityArrayUsed = flats_cf;
				}	
				else {
					System.out.println("The bottom note you specified is not in this chord!");
				}
			}

			chordRootIndex = qualityArrayUsed.indexOf(root);
			updatedChordRoot = qualityArrayUsed.get((chordRootIndex + offset + STEPS)%STEPS);
			chordRootIndex = qualityArrayUsed.indexOf(updatedChordRoot);

			translateToNumericalInversion(root, inv);

			if (updatedChordRoot.equals("b") || updatedChordRoot.equals("e")) {
				qualityArrayUsed = sharps;
			}
			else if (updatedChordRoot.equals("c") || updatedChordRoot.equals("f")) {
				qualityArrayUsed = flats;
			}
		}

		// if inversion is specified using a number 
		else {
			if (sharpsTranspose) {
				if (sharps.contains(root)) {
					qualityArrayUsed = sharps;
				}

				else if (sharps_eb.contains(root)) {
					qualityArrayUsed = sharps_eb;
				}

				else if (flats.contains(root)) {
					qualityArrayUsed = flats;
				}

				else if (flats_cf.contains(root)) { 
					qualityArrayUsed = flats_cf;
				}
			}

			else if (flatsTranspose) {
				if (flats.contains(root)) {
					qualityArrayUsed = flats; 
				}
				else if (flats_cf.contains(root)) { 
					qualityArrayUsed = flats_cf; 
				}
				else if (sharps.contains(root)) {
					qualityArrayUsed = sharps;
				}
				else if (sharps_eb.contains(root)) {
					qualityArrayUsed = sharps_eb;
				}
			}

			else {
				if (sharps.contains(root)) {
					qualityArrayUsed = sharps;
				}

				else if (sharps_eb.contains(root)) {
					qualityArrayUsed = sharps_eb;
				}

				else if (flats.contains(root)) {
					qualityArrayUsed = flats;
				}

				else if (flats_cf.contains(root)) { 
					qualityArrayUsed = flats_cf;
				}
			}
			chordRootIndex = qualityArrayUsed.indexOf(root);
			updatedChordRoot = qualityArrayUsed.get((chordRootIndex + offset + STEPS)%STEPS);
			chordRootIndex = qualityArrayUsed.indexOf(updatedChordRoot);

			if (updatedChordRoot.equals("b") || updatedChordRoot.equals("e")) {
				qualityArrayUsed = sharps;
			}
			else if (updatedChordRoot.equals("c") || updatedChordRoot.equals("f")) {
				qualityArrayUsed = flats;
			}
		}
	}

	/**
	 * Produce, in LilyPond syntax, the string of notes that construct a chord
	 * @param root
	 * @param quality
	 * @param inv
	 * @param key
	 * @param dur
	 * @return
	 */
	public String singleChordString (String root, String quality, String inv, String notes) {

		// reset
		updatedChordRoot = null;
		updatedChordInv = inv;
		
		String noteString="";
		// if inverse not specified, don't shuffle order of the notes in that chord
		int rootNoteIndex = 0;

		if (inv==null) {
			inv = "0";
			updatedChordInv = "0";
		}

		// if parsing custom chord 
		if (notes!=null && root == null && quality == null) {

			// populate outputArray with customNotes
			String[] notesInCustomChord = notes.split(" ");
			for (int i =0; i<notesInCustomChord.length; i++) {
				outputArray.add(str.convertSharpFlat(notesInCustomChord[i]));
			}

			// get numerical inversion given bottom note of chord 
			for (int i =0; i<notesInCustomChord.length; i++) {
				if (outputArray.get(i).equals(inv)) {
					updatedChordInv = Integer.toBinaryString(i);
				}
			}
		}

		// if parsing non-custom chord 
		else {
			root = root.trim();
			quality = quality.trim();
			intArray(quality); 

			// RESET ROOT 
			convertRootAndInversionOfChord(root, inv);

			// create String that describes the root and quality of a chord
			String root_and_quality = updatedChordRoot+" "+quality;
	
			// handle diminished chords 
			if (quality.equals("diminished")) {
				for (int i=0; i<dimMap.get(updatedChordRoot).length; i++ ){
					outputArray.add(dimMap.get(updatedChordRoot)[i]);
				}
			}

			// handle double sharps or double flats 
			else if (enharmonicChords.containsKey(root_and_quality)){
				specialChords(root_and_quality);
				intervalArray = null; 
			}

			// all other chords
			else {
				
				for (int i=0;i<intervalArray.size();i++) {
					outputArray.add(qualityArrayUsed.get((chordRootIndex+ intervalArray.get(i) + STEPS) % STEPS)); //handle offset 
				}

				// note names can be adjacent if the chord has 4 or more notes
				if (outputArray.size()>3) {
					if (adjacentNoteNames()) {
						if (qualityArrayUsed.equals(sharps)) {
							qualityArrayUsed = flats;
						}
						else if (qualityArrayUsed.equals(flats)) {
							qualityArrayUsed = sharps;
						}
						for (int i=0;i<intervalArray.size();i++) {
							outputArray.set(i, qualityArrayUsed.get((chordRootIndex+ intervalArray.get(i) + STEPS) % STEPS)); //handle offset 

						}
					}
				}
			}
		}

		// HANDLE INTEGER INVERSION
		int inversion = Integer.valueOf(updatedChordInv);
		
		// parses valid inversion 
		if (inversion<outputArray.size()) {
			rootNoteIndex = Integer.parseInt(updatedChordInv);
		}
		// error message of inversion if not valid (inversion value too large) 
		else {
			System.out.println("This inversion int is not possible; try a smaller inversion value ");
		}

		// shuffle the array and add each element to noteString 
		String [] result=shuffleArrayIndex(outputArray, rootNoteIndex);

		for (int i=0;i<result.length;i++) {
			noteString+=result[i]+ " ";
		}
		return noteString;
	}

	/**
	 * create outputArray with notes given root and quality 
	 * this method will be called if the root and quality of a chord is any of the following:
	    eis_maj
		eis_min
		fes_maj
		fes_min
		bis_maj
		bis_min
		ces_maj
		ces_min
		dis_maj
		ais_maj
		eis_dom7
	 	fes_dom7 
	 	dis_dom7 
		gis_dom7
		ais_dom7
	 * @param root_and_quality
	 */
	public void specialChords (String root_and_quality) {
		ArrayList<String> enharmChord = new ArrayList<String>();
		enharmChord = enharmonicChords.get(root_and_quality);
		for (int i=0; i<enharmChord.size(); i++) {
			outputArray.add(enharmChord.get(i));
		}
	}

	/**
	 * Main class for running the program 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		// used when running the script
		String fileName = args[0];
		Parser parser = new Parser(fileName);
		
		// get header 
		NoteProducer np = parser.returnSongHeader(); 
		// get song
		ArrayList<Verse> song = parser.returnSong();

		String chordOutput ="";
		String extraLine = "";

		// for every verse, get the name of the verse 
		// and call np.singleChordString on every chord in that verse 
		for (int v=0; v<song.size(); v++) {

			Verse verse = song.get(v);
			String verseName = song.get(v).getName();

			for (int i=0; i<verse.getChords().size(); i++) {

				if (i==0) {
					// at the top of each section, adds a comment in the LilyPond input 	
					// describing the name of the section
					extraLine = "\n   " + "% "+ verseName + "\n   ";
				}
				else {
					extraLine ="";
				}

				String root = verse.getChords().get(i)[0];
				String quality = verse.getChords().get(i)[1];
				String optional_inv = verse.getChords().get(i)[2];
				String duration = verse.getChords().get(i)[3];
				String notes = verse.getChords().get(i)[4];
				chordOutput+=extraLine + "< "+ (np.singleChordString(root, quality, optional_inv, notes))+ "> "+ duration + "\n   ";

				// reset
				np.outputArray.clear();
			}
		}

		String header = np.createHeader(np.title, np.composer);
		String output = "\\version \"2.18.2\"" + "\n" + header + "\n" + "\\score {" + "\n " + 
				"\\relative c" + octave + "{" +  "\n "  +  
				" \\clef " + clef + "\n " + 
				" \\time " + tS_top + "/" + tS_bot + 
				"{ " + "\n " +
				"  \\key " + songKey + 
				"  \\" + songQuality + 
				"{" + "  \n   "+ chordOutput +"}" + "\n" + 
				"  }" +"\n" + " }" + "\n" + "}" + "\n";

		// this output is written into o.txt, which is saved in the ChordInterpreter file.
		// o.txt is an intermediate file that is used as LilyPond input to create the output pdf,
		// and is immediately destroyed after the pdf is saved and displayed
		System.out.println(output);
	}
}