import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Parses the user's input into Strings that the NoteProducer can use to generate o.txt, which is the
 * LilyPond syntax representing the user's input.
 * @author sophiasysun
 *
 */
public class Parser {
	NoteProducer np;
	
	// Notes object
	public Notes n = new Notes();
	ArrayList<String> sharps = n.getSharps();
	ArrayList<String> flats = n.getFlats();
	ArrayList<String> sharps_eb = n.getSharps_eb();
	ArrayList<String> flats_cf = n.getFlats_cf();
	
	// StringManipulation object
	StringManipulation str = new StringManipulation();

	// a song is an array list of verses
	public ArrayList<Verse> song = new ArrayList<Verse> ();
	
	// keep track of the chords in the section/verse that is being declared 
	ArrayList<String []> currSectionChords = new ArrayList<String []>();
	
	// if user declares group of customNotes, keep track of the note names 
	// in the group of customNotes
	HashMap<String, String> customNotes = new HashMap<String, String> ();
	
	// keeps track of all the declared customChords
	HashMap<String, String []> customChordMap = new HashMap<String, String []> ();
	
	int offset = 0;
	boolean declaringNotesOnly = false;

	public Parser (String file) throws FileNotFoundException, IOException {
		// put all non-empty lines and non-comment lines into the String array of lines
		ArrayList<String> txtFile = new ArrayList<String> ();
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = br.readLine()) != null) {
				if (!line.equals("") && (!line.contains("//"))) { 
					txtFile.add(line);
				}
			}
		}

		/** parsing the first line of the file **/
		
		// first line describes key signature and time signature of the song 
		String firstLine = txtFile.get(0); 
		String secondLine = txtFile.get(1); 

		/** PARSE TITLE IF THERE IS ONE **/

		// only reassign if user specifies title and composer
		String title=null;
		String composer = null;
		
		// used to parse info about clef, octave, key signature, transposition, time signature
		String [] arr;

		if (firstLine.contains("by")) {
		
			// title is the substring between the quotation marks
			int firstQuotation = firstLine.indexOf("\"");
			int endOfTitle = firstLine.indexOf("\"", firstQuotation+1);
	
			if (firstQuotation==-1 || endOfTitle==-1) {
				System.out.println("Please surround the song title with quotation marks!");
			}
			
			int beforeComposer = firstLine.indexOf("by");
			title = firstLine.substring(0, endOfTitle+1);
		
			// composer is substring after "by"
			composer = firstLine.substring(beforeComposer+3);
			composer=composer.trim();
			arr = secondLine.split(" ");
		}

		else {
			arr = firstLine.split(" ");
		}

		/** OCTAVE **/

		String octave;
		String song_clef;

		// no octave specified
		if ((arr[0].charAt(arr[0].length()-2)=='s' || arr[0].charAt(arr[0].length()-2)=='e')){
			octave = "";
			song_clef = arr[0].toLowerCase().substring(0, arr[0].length()-1);
		}

		// if octave specified
		else {
			int begOfOct=0; // after clef is specified, check the number of octaves specified

			if (arr[0].contains("treble")) {
				begOfOct = 6;
			}
			else if (arr[0].contains("bass")) {
				begOfOct = 4;
			}
			octave = arr[0].toLowerCase().substring(begOfOct, arr[0].length()-1);
			song_clef = arr[0].toLowerCase().substring(0, begOfOct);
		}

		/** KEY SIGNATURE **/
		
		String song_root = "";
		String song_quality ="";
		String optional_new_song_root ="";

		// no transpose
		if (arr.length==5) {
			song_root = str.convertSharpFlat(str.convertSharpFlat(arr[1].toLowerCase()));
			song_quality = arr[2].toLowerCase().substring(0, arr[2].length()-1);
			offset = 0;
			np = new NoteProducer(song_clef, octave, song_root, song_quality, null, Integer.parseInt(arr[3]), Integer.parseInt(arr[4]), offset, title, composer);
		}

		// transpose
		else if (arr.length==8) {

			// if specifying transposition through number of half steps 
			//bass'', c major -> up 2, 3 4
			//0       1 2     3  4  5  6 7 
			if (arr[4].contains("up") || arr[4].contains("down")) {
				if (arr[4].contains("up")) {
					offset = Integer.valueOf(arr[5].substring(0, arr[5].indexOf(','))); 
				}

				else if (arr[4].contains("down")) {
					offset = -(Integer.valueOf(arr[5].substring(0, arr[5].indexOf(',')))); 
				}

				// original root and quality
				song_root = str.convertSharpFlat(arr[1].toLowerCase());
				song_quality = convertChordQuality(arr[2]);
				optional_new_song_root = null;
			}

			// if specifying original and new key 
			else{
				int oldK=0;
				int newK=0;
				
				// get the note names representing the roots of the oldKey and newKeys
				String oldKey = str.convertSharpFlat(arr[1]);
				String newKey = str.convertSharpFlat(arr[4]);

				// offset is the number of half steps between the newKey and oldKey 
				if (sharps.contains(oldKey) && sharps.contains(newKey)) {
					oldK = sharps.indexOf(oldKey);
					newK = sharps.indexOf(newKey);
					offset = newK - oldK;
				}

				else if (flats.contains(oldKey) && flats.contains(newKey)) {
					oldK = flats.indexOf(oldKey);
					newK = flats.indexOf(newKey);
					offset = newK - oldK;
				}

				else if (sharps_eb.contains(oldKey) && sharps_eb.contains(newKey)) {
					oldK = sharps_eb.indexOf(oldKey);
					newK = sharps_eb.indexOf(newKey);
					offset = newK - oldK;
				}

				else if (flats_cf.contains(oldKey) && flats_cf.contains(newKey)) {
					oldK = flats_cf.indexOf(oldKey);
					newK = flats_cf.indexOf(newKey);
					offset = newK - oldK;
				}
				song_root = str.convertSharpFlat(str.convertSharpFlat(arr[1].toLowerCase()));
				song_quality = arr[2].toLowerCase().substring(0, arr[2].length()); 
				optional_new_song_root = str.convertSharpFlat(str.convertSharpFlat(arr[4].toLowerCase()));
			}

			// create NoteProducer object with all the parsed information
			np = new NoteProducer(song_clef, octave, song_root, song_quality, optional_new_song_root, Integer.parseInt(arr[6]), Integer.parseInt(arr[7]), offset, title, composer);
		}

		/** parsing the remainder of the file **/
		String currSectionName=""; // name of verse whose chords you are looking at 
		boolean inVerse = false; // whether you are currently inside a verse

		// look at all the lines in the remainder of the file
		for (int i = 2; i<txtFile.size(); i++) {
			
			// get and retrieve each line
			String line = txtFile.get(i);
			line = line.trim();
			declaringNotesOnly = false; // reset

			// if you're in a verse, you will either see a chord or a end bracket 
			if (inVerse) {
				// reached the end of the verse
				// create verse object with all the chords that have been accumulating and the name of the verse 
				// add verse to the song
				if (line.contains("}")) {
					String verseName = new String(currSectionName.trim());
					ArrayList<String []> verseChords = new ArrayList<String[]> (currSectionChords);
					Verse v = new Verse (verseName, verseChords);
					song.add(v);
					// after you create the verse, you're no longer in verse, so reset currSectionChords
					inVerse=false;
				}

				// haven't reached end of the verse, so process each chord 
				else {
					String [] constructChord = new String [5];

					if(customChordMap.containsKey(line)) {
						constructChord = customChordMap.get(line);
					}

					// NOT DECLARING NEW CUSTOM CHORD
					else if (!line.contains("=")) {
					
						// if the line does not contain the name of one of the custom chords, 
						// creating regular chord 
						String [] chordArray = line.split(" ");
						constructChord[0]=parseRoot(chordArray[0]);
						constructChord[1]=parseQuality(chordArray[1]);

						// argument at index 2 is duration
						if (!chordArray[2].contains(",")) {
							constructChord[2]=null; // no inversion 
							constructChord[3]=chordArray[2];
							constructChord[4]=null;
						}

						// if argument at index 2 is a letter or int, copy the inv and duration
						else {  
							constructChord[2] = parseInversion(chordArray[2]);
							constructChord[3]=chordArray[3]; // handle duration
							constructChord[4]=null;
						}
					}

					// DECLARING NEW CUSTOM CHORD
					else {
						String customName = line.substring(0, line.indexOf("="));
						customName=customName.trim();

						// if a custom chord with the same name already exists, don't create it
						if(customChordMap.containsKey(customName)) {
							System.out.println("Already created this custom chord, which is called "+customName);
						}

						else {
							// DECLARING NOTES AND DURATION
							if (line.contains(",")) {
								String lineWithCustomChord = line.substring(line.indexOf('(')+1,line.indexOf(')'));
								String [] customChordInfo=lineWithCustomChord.split(",");
								String chordNotes = customChordInfo[0].trim();
								customChordInfo[1]= customChordInfo[1].trim();

								// if, within the parentheses, notes are referred to with the 
								// name of a group of customNotes, get notes stored at that name
								if (customNotes.containsKey(chordNotes)) {
									chordNotes = customNotes.get(chordNotes);
								}

								// INVERSION SPECIFIED
								if (customChordInfo.length==3) {
									constructChord[0]=null;
									constructChord[1]=null;
									constructChord[2]=customChordInfo[1]; // has inversion //parse inversion?
									constructChord[3]=customChordInfo[2].substring(1, 2); // duration
									constructChord[4]=chordNotes;
								}

								// for custom chord, make it a normal chord but make the root and quality null 
								// NO INVERSION SPECIFIED
								else if (customChordInfo.length==2) {
									constructChord[0]=null;
									constructChord[1]=null;
									constructChord[2]=null; // no inversion
									constructChord[3]=customChordInfo[1]; // duration
									constructChord[4]=chordNotes;
								}

								// add the constructed chord to the array of chords in this section 
								customChordMap.put(customName, constructChord);
							}

							// ONLY DECLARING NOTES nameOfCustomNoteGroup
							else {
								String notesOnly = line.substring(line.indexOf('(')+1,line.indexOf(')'));
								notesOnly = notesOnly.trim();
								customNotes.put(customName, notesOnly);
								declaringNotesOnly=true;
							}
						}
					}
					if (!declaringNotesOnly){
						// add the constructed chord to the array of chords in this section 
						currSectionChords.add(constructChord);
					}
				}
			}

			// if you're in a verse you will never see {
			else if (line.contains("{")) { // mark the index 
				// clear all the chords that have been accumulating to reset 
				currSectionChords.removeAll(currSectionChords);
				inVerse=true;
				currSectionName=line.substring(0, line.indexOf("{"));
				currSectionName.trim();
			}

			// if not in verse, and not starting a verse, you must be calling a verse 
			else {
				boolean verseExists=false;

				for (int v=0, n = song.size(); v<n; v++) {
					// if the called verse already exists, which it should
					if (song.get(v).getName().equals(line)) {
						String verseName = new String(song.get(v).getName());
						ArrayList<String []> verseChords = (song.get(v).getChords());
						Verse calledVerse = new Verse (verseName, verseChords); 
						song.add(calledVerse);
						verseExists=true;
						break;
					}
				}
				if (!verseExists) {
					System.out.println("Line " + i + ", which is \"" +line +"\", contains a verse that doesn't exist yet!");
				}
			}
		}
		returnSong();
	}

	/**
	 * Parse chord root by converting to lower case and handling # and b 
	 * @param s
	 * @return
	 */
	public String parseRoot(String s) {
		s = s.toLowerCase();
		s = str.convertSharpFlat(s);
		return str.convertSharpFlat(s);
	}

	/**
	 * Parse chord root by converting diff possible ways to express quality and getting rid of comma 
	 * @param s
	 * @return
	 */
	public String parseQuality(String s) {
		s  = s.substring(0, s.length()-1);
		return convertChordQuality(s);
	}

	/**
	 * Parse chord root by converting diff possible ways to express quality and getting rid of comma 
	 * @param s
	 * @return
	 */
	public String parseInversion(String s) {
		s = s.toLowerCase();
		s = str.convertSharpFlat(s);
		int commaLoc = s.indexOf(",");

		if (commaLoc !=-1) {
			return s.substring(0, commaLoc);
		}
		else return s;
	}

	/**
	 * Return clef, octave, key signature, and time signature of the song 
	 * @return
	 */
	public NoteProducer returnSongHeader (){
		return np;
	}

	/**
	 * Anticipate possible user inputs and translate them into a string that the NoteProducer class can understand
	 * @param chord_quality
	 * @return String 
	 */
	public String convertChordQuality (String chord_quality) {
		if (chord_quality.equals("M") || chord_quality.equals("Major") || chord_quality.equals("maj") || chord_quality.equals("major")) {
			chord_quality = "major";
		}
		else if (chord_quality.equals("m") || chord_quality.equals("minor") || chord_quality.equals("min")) {
			chord_quality = "minor";
		}
		else if (chord_quality.equals("d") || chord_quality.equals("dim") || chord_quality.equals("diminished")) {
			chord_quality = "diminished";
		}
		else if (chord_quality.equals("D7") || chord_quality.equals("Dominant7") ||  chord_quality.equals("Dom7")) {
			chord_quality = "dom7";
		}
		else if (chord_quality.equals("M7") || chord_quality.equals("Major7") || chord_quality.equals("Maj7")) {
			chord_quality = "maj7";
		}
		else if (chord_quality.equals("m7") || chord_quality.equals("Minor7") || chord_quality.equals("Min7")) {
			chord_quality = "min7";
		}
		else if (chord_quality.equals("d7") || chord_quality.equals("Diminished7") || chord_quality.equals("Dim7")) {
			chord_quality = "dim7";
		}
		return chord_quality;
	}


	/**
	 * Get all the verses and their respective chords  
	 * @return
	 */
	public ArrayList<Verse> returnSong (){
		return song;
	}
}